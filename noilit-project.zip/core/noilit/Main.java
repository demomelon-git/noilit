package noilit;

import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;

/** noilit1: конвертация, проверка и запуск .nojar. */
public final class Main {
    public static final String VERSION = "noilit1";

    static final String USAGE =
        "noilit1 — среда выполнения для .nojar\n"
      + "  (без аргументов)                 окно лаунчера (ПК)\n"
      + "  convert <in.jar> <out.nojar>     jar -> nojar\n"
      + "  info <f.nojar>                   состав и метаданные\n"
      + "  check <f.nojar> [--libs dir]     загрузить все классы без запуска\n"
      + "  run <f.nojar> [--main cls] [--libs dir] [--natives dir] [-- аргументы]\n"
      + "  launch <f.nojar> --dir d --libs d --natives d --assets d [--user Name] [--version 1.12.2] [--index 1.12]\n";

    static final class Opts {
        final List<String> pos = new ArrayList<String>(), rest = new ArrayList<String>();
        final Map<String, String> kv = new HashMap<String, String>();
        Opts(String[] a, int from) {
            for (int i = from; i < a.length; i++) {
                if (a[i].equals("--")) { rest.addAll(Arrays.asList(a).subList(i + 1, a.length)); break; }
                if (a[i].startsWith("--") && i + 1 < a.length) kv.put(a[i].substring(2), a[++i]);
                else pos.add(a[i]);
            }
        }
        String pos(int i) {
            if (i >= pos.size()) throw new IllegalArgumentException("Не хватает аргументов\n" + USAGE);
            return pos.get(i);
        }
        String get(String k, String d) { String v = kv.get(k); return v != null ? v : d; }
    }

    public static void main(String[] a) {
        try {
            if (a.length == 0) { Gui.show(); return; }
            Opts o = new Opts(a, 1);
            switch (a[0]) {
                case "convert": {
                    int n = Nojar.convert(new File(o.pos(0)), new File(o.pos(1)));
                    System.out.println("Готово: " + n + " записей -> " + o.pos(1));
                    break;
                }
                case "info": info(o); break;
                case "check": check(o); break;
                case "run": start(o.pos(0), o.get("main", null), o.get("libs", null), o.get("natives", null), o.rest); break;
                case "launch":
                    launchGame(o.pos(0), o.get("libs", "libs"), o.get("natives", "natives"), o.get("assets", "assets"),
                        o.get("dir", "."), o.get("user", "Player"), o.get("version", "1.12.2"), o.get("index", "1.12"));
                    break;
                default: System.out.println(USAGE);
            }
        } catch (Throwable t) {
            t.printStackTrace();
            System.exit(1);
        }
    }

    /** Запуск Minecraft 1.12.2 из .nojar (офлайн-профиль). */
    public static void launchGame(String nojar, String libs, String natives, String assets, String dir,
                                  String user, String version, String index) throws Exception {
        String uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + user).getBytes("UTF-8")).toString().replace("-", "");
        List<String> g = new ArrayList<String>(Arrays.asList(
            "--username", user, "--version", version, "--gameDir", dir, "--assetsDir", assets,
            "--assetIndex", index, "--uuid", uuid, "--accessToken", "0", "--userType", "legacy"));
        start(nojar, null, libs, natives, g);
    }

    static void start(String file, String mainClass, String libs, String natives, List<String> args) throws Exception {
        Nojar nj = new Nojar(new File(file));
        if (mainClass == null) mainClass = nj.meta("Main-Class");
        if (mainClass == null) throw new IllegalStateException("Главный класс не указан: добавьте --main");
        if (natives != null) {
            String p = new File(natives).getAbsolutePath();
            for (String k : new String[]{"java.library.path", "org.lwjgl.librarypath", "net.java.games.input.librarypath"})
                System.setProperty(k, p);
        }
        NojarLoader cl = new NojarLoader(nj, jars(libs), Main.class.getClassLoader());
        Thread.currentThread().setContextClassLoader(cl);
        Method m = Class.forName(mainClass, true, cl).getMethod("main", String[].class);
        System.out.println("[" + VERSION + "] " + mainClass + " <- " + file);
        try {
            m.invoke(null, (Object) args.toArray(new String[0]));
        } catch (InvocationTargetException e) {
            if (e.getCause() instanceof Exception) throw (Exception) e.getCause();
            throw e;
        }
    }

    static URL[] jars(String dir) throws IOException {
        List<URL> r = new ArrayList<URL>();
        if (dir != null) walk(new File(dir), r);
        return r.toArray(new URL[0]);
    }

    private static void walk(File d, List<URL> out) throws IOException {
        File[] fs = d.listFiles();
        if (fs == null) return;
        Arrays.sort(fs);
        for (File f : fs) {
            if (f.isDirectory()) walk(f, out);
            else if (f.getName().endsWith(".jar")) out.add(f.toURI().toURL());
        }
    }

    static void info(Opts o) throws IOException {
        Nojar nj = new Nojar(new File(o.pos(0)));
        try {
            long raw = 0, st = 0; int n = 0, cls = 0;
            for (Nojar.Entry e : nj.entries()) {
                n++; raw += e.rawLen; st += e.storedLen;
                if (e.name.endsWith(".class")) cls++;
            }
            System.out.println(o.pos(0) + ": формат " + Nojar.FORMAT + ", записей " + n + " (классов " + cls + "), "
                + (raw >> 10) + " КБ -> " + (st >> 10) + " КБ");
            for (String k : new String[]{"Runtime", "Main-Class", "Source"}) System.out.println(k + ": " + nj.meta(k));
        } finally { nj.close(); }
    }

    /** Читает все записи (проверяя CRC) и загружает все классы без инициализации. */
    static void check(Opts o) throws Exception {
        Nojar nj = new Nojar(new File(o.pos(0)));
        try {
            NojarLoader cl = new NojarLoader(nj, jars(o.get("libs", null)), Main.class.getClassLoader());
            int ok = 0, bad = 0, files = 0;
            TreeSet<String> missing = new TreeSet<String>();
            for (Nojar.Entry e : nj.entries()) {
                if (!e.name.endsWith(".class")) { nj.read(e.name); files++; continue; }
                try {
                    Class.forName(e.name.substring(0, e.name.length() - 6).replace('/', '.'), false, cl);
                    ok++;
                } catch (LinkageError x) {
                    bad++;
                    String[] p = String.valueOf(x.getMessage()).split("/");
                    missing.add(p.length > 2 ? p[0] + "/" + p[1] + "/" + p[2] : String.valueOf(x.getMessage()));
                } catch (ClassNotFoundException x) { bad++; missing.add(String.valueOf(x.getMessage())); }
            }
            System.out.println("Файлов проверено: " + files + " (CRC ок). Классов загружено: " + ok + ", не загружено: " + bad);
            if (!missing.isEmpty()) System.out.println("Не хватает (нужны --libs): " + missing);
        } finally { nj.close(); }
    }
}
