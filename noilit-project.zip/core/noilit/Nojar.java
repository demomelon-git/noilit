package noilit;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** Контейнер .nojar (формат 1, среда noilit1). Числа — big-endian. См. spec/NOJAR.md. */
public final class Nojar implements Closeable {
    public static final int MAGIC = 0x4E4F4A52; // "NOJR"
    public static final int FORMAT = 1;
    public static final String INF = "META-INF/NOJAR.INF";

    public static final class Entry {
        public final String name;
        public final int method, rawLen, storedLen;
        public final long crc, offset;
        Entry(String name, int method, int rawLen, int storedLen, long crc, long offset) {
            this.name = name; this.method = method; this.rawLen = rawLen;
            this.storedLen = storedLen; this.crc = crc; this.offset = offset;
        }
    }

    private final RandomAccessFile raf;
    private final Map<String, Entry> index = new LinkedHashMap<String, Entry>();
    private Map<String, String> meta;

    public Nojar(File f) throws IOException {
        raf = new RandomAccessFile(f, "r");
        try {
            if (raf.readInt() != MAGIC) throw new IOException("Это не .nojar: " + f);
            int fmt = raf.readUnsignedShort();
            if (fmt != FORMAT) throw new IOException("Неизвестная версия формата: " + fmt);
            int n = raf.readInt();
            for (int i = 0; i < n; i++) {
                byte[] nb = new byte[raf.readUnsignedShort()];
                raf.readFully(nb);
                int method = raf.readUnsignedByte(), raw = raf.readInt(), stored = raf.readInt();
                long crc = raf.readInt() & 0xFFFFFFFFL, off = raf.getFilePointer();
                String name = new String(nb, StandardCharsets.UTF_8);
                index.put(name, new Entry(name, method, raw, stored, crc, off));
                raf.seek(off + stored);
            }
        } catch (IOException e) { raf.close(); throw e; }
    }

    public Collection<Entry> entries() { return index.values(); }
    public boolean has(String name) { return index.containsKey(name); }

    public synchronized byte[] read(String name) throws IOException {
        Entry e = index.get(name);
        if (e == null) throw new FileNotFoundException(name);
        byte[] st = new byte[e.storedLen + 1]; // +1: «пустой» байт для Inflater(nowrap)
        raf.seek(e.offset);
        raf.readFully(st, 0, e.storedLen);
        byte[] raw;
        if (e.method == 0) {
            raw = Arrays.copyOf(st, e.storedLen);
        } else if (e.method == 1) {
            raw = new byte[e.rawLen];
            Inflater inf = new Inflater(true);
            try {
                inf.setInput(st);
                int p = 0;
                while (p < raw.length) {
                    int k = inf.inflate(raw, p, raw.length - p);
                    if (k == 0 && (inf.finished() || inf.needsInput())) break;
                    p += k;
                }
                if (p != raw.length) throw new IOException("Повреждена запись: " + name);
            } catch (DataFormatException ex) {
                throw new IOException("Повреждена запись: " + name, ex);
            } finally { inf.end(); }
        } else throw new IOException("Неизвестный метод " + e.method + ": " + name);
        CRC32 c = new CRC32();
        c.update(raw);
        if (c.getValue() != e.crc) throw new IOException("CRC не совпадает: " + name);
        return raw;
    }

    public InputStream stream(String name) throws IOException {
        return has(name) ? new ByteArrayInputStream(read(name)) : null;
    }

    /** Значение из META-INF/NOJAR.INF (Runtime, Main-Class, Source). */
    public synchronized String meta(String key) {
        if (meta == null) {
            meta = new HashMap<String, String>();
            try {
                if (has(INF))
                    for (String l : new String(read(INF), StandardCharsets.UTF_8).split("\r?\n")) {
                        int i = l.indexOf(':');
                        if (i > 0) meta.put(l.substring(0, i).trim(), l.substring(i + 1).trim());
                    }
            } catch (IOException ignore) { }
        }
        return meta.get(key);
    }

    @Override public void close() throws IOException { raf.close(); }

    // ---------- конвертер jar -> nojar ----------

    private static final class Packed { String name; int method, raw; long crc; byte[] stored; }

    private static Packed pack(String name, byte[] raw) {
        CRC32 c = new CRC32();
        c.update(raw);
        Deflater d = new Deflater(6, true);
        d.setInput(raw);
        d.finish();
        byte[] buf = new byte[raw.length + 64];
        int n = 0;
        while (!d.finished() && n < buf.length) n += d.deflate(buf, n, buf.length - n);
        boolean smaller = d.finished() && n < raw.length;
        d.end();
        Packed p = new Packed();
        p.name = name; p.raw = raw.length; p.crc = c.getValue();
        p.method = smaller ? 1 : 0;
        p.stored = smaller ? Arrays.copyOf(buf, n) : raw;
        return p;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[65536];
        for (int k; (k = in.read(b)) > 0; ) o.write(b, 0, k);
        in.close();
        return o.toByteArray();
    }

    /** Конвертирует jar/zip в .nojar. Подписи и MANIFEST отбрасываются. Возвращает число записей. */
    public static int convert(File jar, File out) throws IOException {
        List<Packed> list = new ArrayList<Packed>();
        String main = null;
        boolean mcMain = false;
        Set<String> names = new HashSet<String>();
        ZipFile z = new ZipFile(jar);
        try {
            for (Enumeration<? extends ZipEntry> en = z.entries(); en.hasMoreElements(); ) {
                ZipEntry ze = en.nextElement();
                String n = ze.getName();
                if (ze.isDirectory() || n.equals(INF)) continue;
                byte[] raw = readAll(z.getInputStream(ze));
                if (n.equals("META-INF/MANIFEST.MF")) {
                    for (String l : new String(raw, StandardCharsets.UTF_8).split("\r?\n"))
                        if (l.startsWith("Main-Class:")) main = l.substring(11).trim();
                    continue;
                }
                if (n.startsWith("META-INF/") && n.matches(".*\\.(SF|RSA|DSA|EC)")) continue;
                if (n.equals("net/minecraft/client/main/Main.class")) mcMain = true;
                names.add(n);
                list.add(pack(n, raw));
            }
        } finally { z.close(); }
        // В манифесте 1.12.2 указан несуществующий net.minecraft.client.Main — проверяем, что класс есть.
        if (main != null && !names.contains(main.replace('.', '/') + ".class")) main = null;
        if (main == null && mcMain) main = "net.minecraft.client.main.Main";
        String inf = "Nojar-Format: " + FORMAT + "\nRuntime: noilit1\nSource: " + jar.getName()
                + (main != null ? "\nMain-Class: " + main : "") + "\n";
        list.add(pack(INF, inf.getBytes(StandardCharsets.UTF_8)));

        DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(out)));
        try {
            o.writeInt(MAGIC); o.writeShort(FORMAT); o.writeInt(list.size());
            for (Packed p : list) {
                byte[] nb = p.name.getBytes(StandardCharsets.UTF_8);
                o.writeShort(nb.length); o.write(nb);
                o.writeByte(p.method); o.writeInt(p.raw); o.writeInt(p.stored.length); o.writeInt((int) p.crc);
                o.write(p.stored);
            }
        } finally { o.close(); }
        return list.size();
    }
}
