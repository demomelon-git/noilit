package noilit;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Properties;

/** Окно лаунчера для ПК. Настройки: ~/.noilit/launcher.properties */
final class Gui {
    /** Значок noilit1 — тот же куб, что и в приложении Android. */
    static Image icon() {
        BufferedImage im = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = im.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new Color(0x10151C));
        g.fillRoundRect(0, 0, 64, 64, 14, 14);
        face(g, 0x6EA8FF, 54, 26, 78, 40, 54, 54, 30, 40);
        face(g, 0x2F5BEA, 30, 40, 54, 54, 54, 82, 30, 68);
        face(g, 0x1B3A99, 54, 54, 78, 40, 78, 68, 54, 82);
        g.dispose();
        return im;
    }

    private static void face(Graphics2D g, int rgb, int... p) {
        int n = p.length / 2;
        int[] x = new int[n], y = new int[n];
        for (int i = 0; i < n; i++) {
            x[i] = (int) Math.round((p[2 * i] - 20) * 64 / 68.0);
            y[i] = (int) Math.round((p[2 * i + 1] - 20) * 64 / 68.0);
        }
        g.setColor(new Color(rgb));
        g.fillPolygon(x, y, n);
    }

    static void show() {
        final File cfg = new File(System.getProperty("user.home"), ".noilit/launcher.properties");
        final Properties p = new Properties();
        try (InputStream in = new FileInputStream(cfg)) { p.load(in); } catch (IOException ignore) { }
        final String[] keys = {"nojar", "libs", "natives", "assets", "dir"};
        final String[] names = {"Файл .nojar", "Библиотеки", "Natives", "Assets", "Папка игры"};
        final JTextField[] f = new JTextField[keys.length];
        final JFrame w = new JFrame("noilit1");
        JPanel g = new JPanel(new GridLayout(0, 3, 6, 6));
        g.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        for (int i = 0; i < keys.length; i++) {
            final JTextField t = f[i] = new JTextField(p.getProperty(keys[i], ""), 28);
            final boolean file = i == 0;
            JButton b = new JButton("Выбрать…");
            b.addActionListener(e -> {
                JFileChooser c = new JFileChooser(t.getText().isEmpty() ? null : new File(t.getText()));
                c.setFileSelectionMode(file ? JFileChooser.FILES_ONLY : JFileChooser.DIRECTORIES_ONLY);
                if (c.showOpenDialog(w) == JFileChooser.APPROVE_OPTION) t.setText(c.getSelectedFile().getPath());
            });
            g.add(new JLabel(names[i])); g.add(t); g.add(b);
        }
        final JTextField user = new JTextField(p.getProperty("user", "Player"));
        JButton go = new JButton("Запустить");
        g.add(new JLabel("Ник")); g.add(user); g.add(go);
        go.addActionListener(e -> {
            for (int i = 0; i < keys.length; i++) p.setProperty(keys[i], f[i].getText().trim());
            p.setProperty("user", user.getText().trim());
            cfg.getParentFile().mkdirs();
            try (OutputStream out = new FileOutputStream(cfg)) { p.store(out, "noilit1"); } catch (IOException ignore) { }
            w.setVisible(false);
            new Thread(() -> {
                try {
                    Main.launchGame(p.getProperty("nojar"), p.getProperty("libs"), p.getProperty("natives"),
                        p.getProperty("assets"), p.getProperty("dir"), p.getProperty("user"), "1.12.2", "1.12");
                } catch (Throwable t) {
                    t.printStackTrace();
                    JOptionPane.showMessageDialog(null, String.valueOf(t), "noilit1", JOptionPane.ERROR_MESSAGE);
                    w.setVisible(true);
                }
            }, "noilit-game").start();
        });
        w.setIconImage(icon());
        w.add(g);
        w.pack();
        w.setLocationRelativeTo(null);
        w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        w.setVisible(true);
    }
}
