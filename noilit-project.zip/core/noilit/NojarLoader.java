package noilit;

import java.io.*;
import java.net.*;
import java.util.*;

/** Загрузчик классов noilit1: классы и ресурсы берутся из .nojar, остальное — из библиотек. */
public final class NojarLoader extends URLClassLoader {
    private final Nojar nojar;

    private final URLStreamHandler handler = new URLStreamHandler() {
        @Override protected URLConnection openConnection(URL u) {
            final String name = u.getPath();
            return new URLConnection(u) {
                @Override public void connect() { }
                @Override public InputStream getInputStream() throws IOException {
                    InputStream in = nojar.stream(name);
                    if (in == null) throw new FileNotFoundException(name);
                    return in;
                }
            };
        }
    };

    public NojarLoader(Nojar nojar, URL[] libs, ClassLoader parent) {
        super(libs, parent);
        this.nojar = nojar;
    }

    @Override protected Class<?> findClass(String name) throws ClassNotFoundException {
        String path = name.replace('.', '/') + ".class";
        if (!nojar.has(path)) return super.findClass(name);
        try {
            byte[] b = nojar.read(path);
            int dot = name.lastIndexOf('.');
            if (dot > 0 && getPackage(name.substring(0, dot)) == null) {
                try { definePackage(name.substring(0, dot), null, null, null, null, null, null, null); }
                catch (IllegalArgumentException ignore) { }
            }
            return defineClass(name, b, 0, b.length);
        } catch (IOException e) {
            throw new ClassNotFoundException(name, e);
        }
    }

    @Override public InputStream getResourceAsStream(String name) {
        try {
            InputStream in = nojar.stream(name);
            if (in != null) return in;
        } catch (IOException ignore) { }
        return super.getResourceAsStream(name);
    }

    @Override public URL findResource(String name) {
        if (nojar.has(name)) {
            try { return new URL(null, "nojar:" + name, handler); } catch (MalformedURLException ignore) { }
        }
        return super.findResource(name);
    }

    @Override public Enumeration<URL> findResources(String name) throws IOException {
        URL u = findResource(name);
        return u == null ? Collections.<URL>emptyEnumeration() : Collections.enumeration(Collections.singletonList(u));
    }
}
