# noilit1

Среда выполнения **noilit** (версия `noilit1`) с собственным контейнером кода **.nojar**.

| Папка | Что внутри |
|---|---|
| `core/` | Java 8: чтение/запись .nojar, загрузчик классов, конвертер, проверка, запуск, окно лаунчера для ПК |
| `editor/index.html` | Веб-редактор: открывает .jar/.nojar, правит файлы, сохраняет .nojar (работает офлайн) |
| `android/` | Приложение-лаунчер для Android (Gradle) |
| `spec/NOJAR.md` | Описание формата |
| `.github/workflows/build.yml` | Сборка на GitHub: `noilit1.jar` для ПК + APK для Android |

## Конвертация Minecraft 1.12.2
```
java -jar noilit1.jar convert 1_12_2.jar 1_12_2.nojar
java -jar noilit1.jar check 1_12_2.nojar --libs <папка с библиотеками>
```
Или откройте jar в `editor/index.html` и нажмите «Сохранить .nojar».

## Запуск на ПК
Нужны библиотеки, natives и assets из официального лаунчера (`.minecraft`).
```
java -jar noilit1.jar            # окно лаунчера
java -jar noilit1.jar launch 1_12_2.nojar --dir game --libs libs --natives natives --assets assets --user Name
```

## Android
GitHub → Actions → артефакт `noilit1-android-apk`. Экран: слева единственный пункт «Загрузить 1.12.2»,
внизу «Запустить». В «Загрузить 1.12.2» выберите `.jar` (конвертируется в `.nojar` на телефоне),
готовый `.nojar` или `.zip` с рантаймом (`jre/`, `libs/`, `natives/`, `assets/`).
Нужна сборка OpenJDK под Android (aarch64) и слой OpenGL/LWJGL2 в `natives/` — в проект они не входят.

## Важно
Minecraft принадлежит Mojang. Не выкладывайте `.jar`/`.nojar` игры в публичный репозиторий —
`.gitignore` уже исключает их. Конвертация и запуск предназначены для вашей собственной копии.
