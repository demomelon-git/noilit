package noilit.android;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.zip.*;
import noilit.Nojar;

/**
 * Лаунчер noilit1. Слева — панель с одним пунктом «Загрузить 1.12.2» (.jar конвертируется в .nojar
 * прямо на телефоне; .zip — рантайм с папками jre, libs, natives, assets). Снизу — «Запустить».
 */
public class MainActivity extends Activity {
    static final int PICK = 1, MATCH = -1, WRAP = -2;
    static final int BG = 0xFF10151C, PANEL = 0xFF171E27, INK = 0xFFE6EBF2, MUT = 0xFF8B97A8,
        AC = 0xFF2F5BEA, AC2 = 0xFF1D2A4A, OFF = 0xFF2A3340;

    File home;
    TextView status, log, itemSub;
    EditText user;
    ScrollView scroll;
    Button go;
    boolean running, busy;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        home = new File(getFilesDir(), "noilit");
        home.mkdirs();

        // боковая панель: единственный пункт
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setBackgroundColor(PANEL);
        side.setPadding(dp(12), dp(16), dp(12), dp(16));
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(dp(14), dp(12), dp(14), dp(12));
        item.setBackground(round(AC2, 12));
        item.setClickable(true);
        itemSub = text("", 12, MUT, false);
        item.addView(text("Загрузить 1.12.2", 15, INK, true));
        item.addView(itemSub);
        item.setOnClickListener(v -> pick());
        side.addView(item, new LinearLayout.LayoutParams(MATCH, WRAP));

        // центр: значок, ник, статус, журнал
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        mid.setPadding(dp(20), dp(16), dp(20), dp(8));
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_launcher_fg);
        mid.addView(icon, new LinearLayout.LayoutParams(dp(96), dp(96)));
        mid.addView(text("noilit1", 22, INK, true));
        user = new EditText(this);
        user.setText("Player");
        user.setHint("Ник");
        user.setSingleLine();
        user.setGravity(Gravity.CENTER);
        user.setTextColor(INK);
        user.setHintTextColor(MUT);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(dp(180), WRAP);
        ulp.topMargin = dp(12);
        mid.addView(user, ulp);
        status = text("", 13, MUT, false);
        status.setGravity(Gravity.CENTER);
        mid.addView(status);
        log = text("", 12, MUT, false);
        log.setTypeface(Typeface.MONOSPACE);
        log.setTextIsSelectable(true);
        scroll = new ScrollView(this);
        scroll.addView(log);
        scroll.setVisibility(View.GONE);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
        slp.topMargin = dp(12);
        mid.addView(scroll, slp);

        LinearLayout row = new LinearLayout(this);
        row.addView(side, new LinearLayout.LayoutParams(0, MATCH, 2f));
        row.addView(mid, new LinearLayout.LayoutParams(0, MATCH, 3f));

        // низ: кнопка запуска
        go = new Button(this);
        go.setAllCaps(false);
        go.setTextSize(18);
        go.setTextColor(Color.WHITE);
        go.setStateListAnimator(null);
        go.setOnClickListener(v -> start());
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(BG);
        bar.setPadding(dp(16), dp(10), dp(16), dp(14));
        bar.addView(go, new LinearLayout.LayoutParams(MATCH, dp(56)));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.addView(row, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        root.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));
        setContentView(root);

        try { copy(getAssets().open("noilit1.jar"), new File(home, "noilit1.jar")); }
        catch (IOException e) { say("Нет noilit1.jar в assets: " + e); }
        refresh();
    }

    // ---------- состояние ----------

    void refresh() {
        File g = new File(home, "game.nojar");
        boolean ok = g.exists(), rt = new File(home, "rt/jre/bin/java").exists();
        itemSub.setText(ok ? "1.12.2 загружена · " + (g.length() >> 20) + " МБ" : "Выберите .jar или .nojar");
        status.setText(busy ? "Подождите…" : !ok ? "Игра не загружена"
            : rt ? "Готово к запуску" : "Нужен рантайм: выберите .zip через «Загрузить 1.12.2»");
        go.setEnabled(ok && !running && !busy);
        go.setBackground(round(go.isEnabled() ? AC : OFF, 14));
        go.setText(running ? "Игра запущена…" : "Запустить");
    }

    void say(final String s) {
        runOnUiThread(() -> {
            log.append(s + "\n");
            scroll.setVisibility(View.VISIBLE);
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    // ---------- загрузка 1.12.2 / рантайма ----------

    void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK);
    }

    @Override protected void onActivityResult(int code, int res, Intent data) {
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri u = data.getData();
        final String n = nameOf(u).toLowerCase();
        busy = true;
        refresh();
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(u);
                if (n.endsWith(".zip")) {
                    say("Установка рантайма…");
                    File rt = new File(home, "rt");
                    rm(rt);
                    unzip(in, rt);
                    say("Рантайм установлен");
                } else {
                    File src = new File(home, "game.src"), out = new File(home, "game.part");
                    say("Копирование…");
                    copy(in, src);
                    if (n.endsWith(".nojar")) {
                        out.delete();
                        if (!src.renameTo(out)) throw new IOException("Не удалось переместить файл");
                    } else {
                        say("Конвертация в nojar…");
                        Nojar.convert(src, out);
                        src.delete();
                    }
                    Nojar nj = new Nojar(out);
                    boolean mc = nj.has("net/minecraft/client/main/Main.class");
                    int count = nj.entries().size();
                    nj.close();
                    File game = new File(home, "game.nojar");
                    game.delete();
                    if (!out.renameTo(game)) throw new IOException("Не удалось сохранить game.nojar");
                    say(mc ? "Minecraft 1.12.2 готова: " + count + " файлов"
                           : "Внимание: клиента Minecraft в архиве не нашлось");
                }
            } catch (Exception e) {
                say("Ошибка: " + e);
            } finally {
                busy = false;
                runOnUiThread(this::refresh);
            }
        }).start();
    }

    String nameOf(Uri u) {
        Cursor c = getContentResolver().query(u, null, null, null, null);
        try {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && c.getString(i) != null) return c.getString(i);
            }
        } finally { if (c != null) c.close(); }
        String p = u.getLastPathSegment();
        return p == null ? "" : p;
    }

    // ---------- запуск ----------

    void start() {
        if (running) return;
        final File rt = new File(home, "rt"), java = new File(rt, "jre/bin/java");
        if (!java.exists()) {
            say("Нет рантайма (jre/bin/java). Выберите .zip с папками jre, libs, natives, assets.");
            return;
        }
        running = true;
        refresh();
        final String typed = user.getText().toString().trim();
        final String name = typed.isEmpty() ? "Player" : typed;
        new Thread(() -> {
            try {
                File game = new File(home, "game");
                game.mkdirs();
                ProcessBuilder pb = new ProcessBuilder(java.getPath(), "-jar", new File(home, "noilit1.jar").getPath(),
                    "launch", new File(home, "game.nojar").getPath(), "--dir", game.getPath(),
                    "--libs", new File(rt, "libs").getPath(), "--natives", new File(rt, "natives").getPath(),
                    "--assets", new File(rt, "assets").getPath(), "--user", name);
                pb.environment().put("JAVA_HOME", new File(rt, "jre").getPath());
                pb.redirectErrorStream(true);
                Process p = pb.start();
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
                for (String l; (l = r.readLine()) != null; ) say(l);
                say("Процесс завершён: " + p.waitFor());
            } catch (Exception e) {
                say("Ошибка запуска: " + e);
            } finally {
                running = false;
                runOnUiThread(this::refresh);
            }
        }).start();
    }

    // ---------- утилиты ----------

    int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static void rm(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) rm(x);
        f.delete();
    }

    static void copy(InputStream in, File out) throws IOException {
        OutputStream o = new FileOutputStream(out);
        try {
            byte[] b = new byte[65536];
            for (int k; (k = in.read(b)) > 0; ) o.write(b, 0, k);
        } finally { o.close(); in.close(); }
    }

    static void unzip(InputStream in, File dir) throws IOException {
        ZipInputStream z = new ZipInputStream(in);
        String root = dir.getCanonicalPath() + File.separator;
        for (ZipEntry e; (e = z.getNextEntry()) != null; ) {
            File f = new File(dir, e.getName());
            if (!f.getCanonicalPath().startsWith(root)) throw new IOException("Недопустимый путь: " + e.getName());
            if (e.isDirectory()) { f.mkdirs(); continue; }
            f.getParentFile().mkdirs();
            OutputStream o = new FileOutputStream(f);
            try {
                byte[] b = new byte[65536];
                for (int k; (k = z.read(b)) > 0; ) o.write(b, 0, k);
            } finally { o.close(); }
            if (e.getName().contains("/bin/")) f.setExecutable(true, false);
        }
        z.close();
    }
}
