package noilit.android;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import java.io.*;
import java.util.zip.*;

/**
 * Лаунчер noilit1 для Android. Не содержит JVM: запускает jre/bin/java из импортированного рантайма
 * с noilit1.jar (тот же код, что и на ПК). Папка рантайма: <files>/noilit/rt/{jre,libs,natives,assets}.
 */
public class MainActivity extends Activity {
    static final int PICK_NOJAR = 1, PICK_RT = 2;
    TextView log;
    ScrollView scroll;
    EditText user;
    File home;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        home = new File(getFilesDir(), "noilit");
        home.mkdirs();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);
        user = new EditText(this);
        user.setText("Player");
        root.addView(user);
        root.addView(button("Выбрать .nojar", PICK_NOJAR));
        root.addView(button("Импорт рантайма (.zip)", PICK_RT));
        Button go = new Button(this);
        go.setText("Запустить");
        go.setOnClickListener(v -> start());
        root.addView(go);
        log = new TextView(this);
        log.setTypeface(Typeface.MONOSPACE);
        log.setTextIsSelectable(true);
        scroll = new ScrollView(this);
        scroll.addView(log);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        try { copy(getAssets().open("noilit1.jar"), new File(home, "noilit1.jar")); say("noilit1 готов"); }
        catch (IOException e) { say("Нет noilit1.jar в assets: " + e); }
    }

    Button button(String t, final int code) {
        Button b = new Button(this);
        b.setText(t);
        b.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, code);
        });
        return b;
    }

    @Override protected void onActivityResult(final int code, int res, Intent data) {
        if (res != RESULT_OK || data == null) return;
        final Uri u = data.getData();
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(u);
                if (code == PICK_NOJAR) { copy(in, new File(home, "game.nojar")); say("game.nojar загружен"); }
                else { unzip(in, new File(home, "rt")); say("Рантайм установлен"); }
            } catch (Exception e) { say("Ошибка: " + e); }
        }).start();
    }

    void start() {
        final String name = user.getText().toString().trim();
        new Thread(() -> {
            try {
                File rt = new File(home, "rt"), java = new File(rt, "jre/bin/java");
                if (!java.exists()) { say("Нет rt/jre/bin/java — импортируйте рантайм (.zip с папками jre, libs, natives, assets)"); return; }
                File game = new File(home, "game"); game.mkdirs();
                ProcessBuilder pb = new ProcessBuilder(java.getPath(), "-jar", new File(home, "noilit1.jar").getPath(),
                    "launch", new File(home, "game.nojar").getPath(), "--dir", game.getPath(),
                    "--libs", new File(rt, "libs").getPath(), "--natives", new File(rt, "natives").getPath(),
                    "--assets", new File(rt, "assets").getPath(), "--user", name.isEmpty() ? "Player" : name);
                pb.environment().put("JAVA_HOME", new File(rt, "jre").getPath());
                pb.redirectErrorStream(true);
                Process p = pb.start();
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
                for (String l; (l = r.readLine()) != null; ) say(l);
                say("Процесс завершён: " + p.waitFor());
            } catch (Exception e) { say("Ошибка запуска: " + e); }
        }).start();
    }

    static void copy(InputStream in, File out) throws IOException {
        OutputStream o = new FileOutputStream(out);
        byte[] b = new byte[65536];
        for (int k; (k = in.read(b)) > 0; ) o.write(b, 0, k);
        o.close(); in.close();
    }

    static void unzip(InputStream in, File dir) throws IOException {
        ZipInputStream z = new ZipInputStream(in);
        String root = dir.getCanonicalPath() + File.separator;
        for (ZipEntry e; (e = z.getNextEntry()) != null; ) {
            File f = new File(dir, e.getName());
            if (!f.getCanonicalPath().startsWith(root)) throw new IOException("Недопустимый путь: " + e.getName());
            if (e.isDirectory()) { f.mkdirs(); continue; }
            f.getParentFile().mkdirs();
            copyNoClose(z, f);
            if (e.getName().contains("/bin/")) f.setExecutable(true, false);
        }
        z.close();
    }

    static void copyNoClose(InputStream in, File out) throws IOException {
        OutputStream o = new FileOutputStream(out);
        byte[] b = new byte[65536];
        for (int k; (k = in.read(b)) > 0; ) o.write(b, 0, k);
        o.close();
    }

    void say(final String s) {
        runOnUiThread(() -> { log.append(s + "\n"); scroll.post(() -> scroll.fullScroll(ScrollView.FOCUS_DOWN)); });
    }
}
