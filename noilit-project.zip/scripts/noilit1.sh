#!/bin/sh
exec java -jar "$(dirname "$0")/noilit1.jar" "$@"
