@echo off
java -jar "%~dp0noilit1.jar" %*
